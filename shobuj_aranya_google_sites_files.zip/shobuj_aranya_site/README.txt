সবুজ অরণ্য ওয়েবসাইট ফাইল

ফাইল:
- index.html: ওয়েবসাইটের সম্পূর্ণ HTML
- images/triphala-mix.jpg: ত্রিফলা মিক্সের আসল ছবি
- images/beetroot-powder.jpg: বিটরুট পাউডারের আসল ছবি
- images/roselle-tea.jpg: রোজেলা চায়ের আসল ছবি

Google Sites Embed-এ HTML পেস্ট করার আগে:
1. Google Sites-এর Embed > Embed code-এ HTML কোড পেস্ট করা যায়, কিন্তু নিজের কম্পিউটার/ফোনের local image path সেখানে কাজ করবে না।
2. আগে images ফোল্ডারের ৩টি ছবি অনলাইনে প্রকাশযোগ্য জায়গায় (যেমন GitHub repository) আপলোড করুন।
3. প্রতিটি ছবির সরাসরি public image URL কপি করুন।
4. index.html-এ নিচের placeholder-গুলো খুঁজে URL দিয়ে বদলান:
   PASTE_TRIPHALA_IMAGE_URL_HERE
   PASTE_BEETROOT_IMAGE_URL_HERE
   PASTE_ROSELLE_IMAGE_URL_HERE
5. WhatsApp অর্ডার পাঠানোর নম্বরটি কোডে 8801943733624 হিসেবে দেওয়া আছে। এটি 01943733624-এর আন্তর্জাতিক ফরম্যাট। অন্য নম্বর হলে WHATSAPP_NUMBER বদলান।
6. HTML ফাইল ব্রাউজারে খুলে পরীক্ষা করুন। Google Sites-এর embed frame-এ ফর্ম/WhatsApp খোলার আচরণ ব্রাউজার ও Google Sites-এর সীমাবদ্ধতার ওপর নির্ভর করতে পারে।
